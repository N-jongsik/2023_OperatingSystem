#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>
#include <linux/unistd.h>
#include <fcntl.h>
#include <time.h>

#define MAX_PROCESSES 64

int count = 0;

void add()
{
    FILE* file_read = fopen("temp.txt", "r"); //file open

    char string_number[10];
    char* temp;
    int num1, num2;

    for (int i = 0; i < count * 2; i++)
    {
        fgets(string_number, sizeof(string_number), file_read); //get from temp.txt
    }

    temp = fgets(string_number, sizeof(string_number), file_read); //get num1
    num1 = atoi(temp); //char to int

    temp = fgets(string_number, sizeof(string_number), file_read); //get num2
    num2 = atoi(temp); //char to int

    fclose(file_read); //file close

    exit(num1+num2);
}

int main()
{
    struct timespec start, end;

    pid_t pid;
    int status;

    clock_gettime(CLOCK_MONOTONIC, &start); //time start

    for (int i = 0; i < MAX_PROCESSES * 2 - 1; i++)
    {
        if ((pid = fork()) == 0) //child
        {
            add();
        }
        else //parent
        {
            waitpid(pid, &status, 0);

            FILE* file_write = fopen("temp.txt", "a");	//file open

            fprintf(file_write, "%d\n", status >> 8);	//right shift 8
            fclose(file_write);	//file close

            count++;
            if (count == MAX_PROCESSES * 2 - 1)
            {
                printf("value of fork : %d\n", status >> 8); //print result
            }
        }
    }

    clock_gettime(CLOCK_MONOTONIC, &end); //time end

    printf("%.6f\n", ((double)end.tv_sec + 1.0e-9 * end.tv_nsec) - ((double)start.tv_sec + 1.0e-9 * start.tv_nsec)); //print execute time

    return 0;
}


