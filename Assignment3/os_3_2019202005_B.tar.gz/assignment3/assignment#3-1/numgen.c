#include <stdio.h>

#define MAX_PROCESS 64
int main()
{
	FILE * file_write;		
	file_write = fopen("temp.txt","wr");		//file open

	for(int i = 0; i < MAX_PROCESS*2; i++)
	{
		fprintf(file_write, "%d\n", i+1);		//write number
	}
	fclose(file_write);				//file close
	return 0;
}				

