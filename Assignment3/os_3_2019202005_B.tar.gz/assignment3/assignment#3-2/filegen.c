#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<sys/stat.h>
#include<sys/types.h>

#define MAX_PROCESSES 10000

int main()
{

	if(mkdir("./temp",0777) != 0)	//make directory
	{
		printf("Make directory error\n");
		return -1;	//exception handling
	}	

	for(int i = 0; i < MAX_PROCESSES; i++)
	{
		char * file_name;
		sprintf(file_name, "./temp/%d.txt", i);

		FILE * file_write = fopen(file_name,"w");	//file open
		fprintf(file_write, "%d", 1 + rand() % 9);	//write random number on file
		fclose(file_write);	//file close
	}
	return 0;
}


