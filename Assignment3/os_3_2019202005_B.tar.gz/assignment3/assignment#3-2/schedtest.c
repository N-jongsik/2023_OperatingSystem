#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sched.h>
#include<time.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<sys/resource.h>
#include<sys/time.h>

#define MAX_PROCESSES 10000

int main()
{
    struct timespec start, end;
    struct sched_param param;
    int cpu_scheduler;
    int priority;
    pid_t pid;
    FILE* file_read;
    char file_name[100];

    printf("==========CPU SCHEDULER==========\n");
    printf("1. The standard round-robin time-sharing policy\n");
    printf("2. A first-in first-out policy\n");
    printf("3. A round-robin policy\n\n");

    printf("Select CPU Scheduler(1,2,3): ");
    scanf("%d", &cpu_scheduler);
	if((cpu_scheduler !=1) &&(cpu_scheduler !=2)&&(cpu_scheduler !=3))
		return 0;

    printf("\n============PRIORITY============\n");
    printf("1. Highest\n");
    printf("2. Default\n");
    printf("3. Lowest\n\n");

    printf("Select Priority(1,2,3): ");
    scanf("%d", &priority);

    clock_gettime(CLOCK_MONOTONIC, &start);//start time

    for (int i = 0; i < MAX_PROCESSES; i++)
    {
        if ((pid = fork()) == 0) //child process
        {
            if (cpu_scheduler == 1)   //The standard round-robin time-sharing policy
            {
		        param.sched_priority = 0;
                //nice set
                if (priority == 1)
                    nice(-20);
                else if (priority == 2)
                    nice(0);
                else if (priority == 3)
                    nice(19);

                sched_setscheduler(getpid(), SCHED_OTHER, &param);
            }
            else if (cpu_scheduler == 2)  //A first-in first-out policy
            {
                if (priority == 1)
                    param.sched_priority = 99;
                else if (priority == 2)
                    param.sched_priority = 50;
                else if (priority == 3)
                    param.sched_priority = 1;
                sched_setscheduler(getpid(), SCHED_FIFO, &param);
            }
            else if (cpu_scheduler == 3)  //A round-robin policy
            {
                if (priority == 1)
                    param.sched_priority = 99;
                else if (priority == 2)
                    param.sched_priority = 50;
                else if (priority == 3)
                    param.sched_priority = 1;
                sched_setscheduler(getpid(), SCHED_RR, &param);
            }
            sprintf(file_name, "./temp/%d.txt", i);
            file_read = fopen(file_name, "r");

            int num = 0;
            fscanf(file_read, "%d", &num);
            fclose(file_read);
            exit(0);
        }
        else //parent process
        {
            wait(NULL);
        }
    }

    clock_gettime(CLOCK_MONOTONIC, &end); //end time

    printf("\n==========================\n");
    printf("Execution Time: %.6f\n", ((double)end.tv_sec + 1.0e-9 * end.tv_nsec) - ((double)start.tv_sec + 1.0e-9 * start.tv_nsec)); //print execute time

    return 0;

}
