#include <linux/ftrace.h>
#include <linux/kallsyms.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/linkage.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/highmem.h>
#include <asm/syscall_wrapper.h>
#include <linux/pid.h>

#define __NR_ftrace 336

typedef asmlinkage long (*sys_call_ptr_t)(const struct pt_regs);
static sys_call_ptr_t *sys_call_table;
sys_call_ptr_t real_ftrace;

asmlinkage int process_tracer(const struct pt_regs *regs)
{
	pid_t pid = regs->di;

	struct task_struct * task = &init_task;
	do
	{
		if(pid == task->pid)
			break;
		task = next_task(task);
	} while ((task->pid != init_task.pid));
	
	if(task->pid != pid)
		return -1;
	
	printk("##### TASK INFORMATION of ''[%d] %s'' #####\n", task->pid, task->comm);

	//state
	int state = task->state;
	if (state == 0x0000)
		printk(" - task state : Running or ready\n");
	else if (state == 0x0001)
		printk(" - task state : Wait \n");
	else if (state == 0x0002)
		printk(" - task state : Wait with ignoring all signals\n");
	else if (state == 0x0004)
		printk(" - task state : Stopped \n");
	else if (state == 0x0010)
		printk(" - task state : Dead \n");
	else if (state == 0x0020)
		printk(" - task state : Zombie process \n");
	else 
		printk(" - task state : etc. \n");


	struct task_struct *group = task->group_leader;
	
	printk(" - Process Group Leader : [%d] %s\n", group->pid, group->comm);
	
	printk(" - Number of context switches : %d\n", task->nvcsw);

	printk(" - Number of calling fork() : %d\n", task->fork_count);

	struct task_struct *parent = task->parent;

	printk(" - it' parent process : [%d] %s\n",parent->pid, parent->comm);

	struct task_struct *sibling;
	struct list_head *sibling_list;

	int count = 0;//sibling count

	printk(" - it's sibling process(es) : \n");

	list_for_each(sibling_list, &task->parent->children)
	{
		sibling = list_entry(sibling_list, struct task_struct, sibling);
		if(sibling->pid != pid)
		{
			printk("		> [%d] %s\n",sibling->pid, sibling->comm);
			count++;
		}
	}

	if(count == 0)
	{
		printk("		> It has no sibling.\n");
	}
	else
	{
		printk("		> This process has %d sibling process(es)\n",count);
	}

	struct task_struct *children;
	struct list_head *child_list;

	int count_child = 0;//child count

	printk(" - it's child process(es) : \n");

	list_for_each(child_list, &task->children)
	{
		children = list_entry(child_list, struct task_struct, sibling);
		printk("		> [%d] %s\n",children->pid, children->comm);
		count_child++;
	}

	if(count_child == 0)
	{
		printk("		> It has no chlid.\n");
	}
	else
	{
		printk("		> This process has %d child process(es)\n",count_child);
	}

	printk("##### END OF INFORMATION #####\n");

	return pid;

}

void make_rw(void* addr)
{
	unsigned int level;
	pte_t* pte = lookup_address((unsigned long)addr, &level);
	if (pte->pte & ~_PAGE_RW)
		pte->pte |= _PAGE_RW;
}

void make_ro(void* addr)
{
	unsigned int level;
	pte_t* pte = lookup_address((unsigned long)addr, &level);
	pte->pte = pte->pte & ~_PAGE_RW;
}
asmlinkage int __init hooking_init(void)
{
	sys_call_table = (sys_call_ptr_t *)kallsyms_lookup_name("sys_call_table");
	make_rw(sys_call_table);
	real_ftrace = sys_call_table[__NR_ftrace];
	sys_call_table[__NR_ftrace] = (sys_call_ptr_t)process_tracer;
	return 0;
}

asmlinkage void __exit hooking_exit(void)
{
	sys_call_table = (sys_call_ptr_t *)kallsyms_lookup_name("sys_call_table");
	sys_call_table[__NR_ftrace] = real_ftrace;
	make_ro(sys_call_table);
}

module_init(hooking_init);
module_exit(hooking_exit);
MODULE_LICENSE("GPL");





