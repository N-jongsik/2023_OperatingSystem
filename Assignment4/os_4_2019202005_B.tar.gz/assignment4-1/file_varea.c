#include <linux/ftrace.h>
#include <linux/kallsyms.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/linkage.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/highmem.h>
#include <asm/syscall_wrapper.h>
#include <linux/pid.h>
#include <linux/mm.h>     
#include <asm/unistd.h>
#include <linux/fs.h>
#include <linux/path.h>

#define __NR_ftrace 336

typedef asmlinkage long (*sys_call_ptr_t)(const struct pt_regs);
static sys_call_ptr_t *sys_call_table;
sys_call_ptr_t real_ftrace;

asmlinkage int file_varea(const struct pt_regs *regs)
{
	pid_t pid = regs->di;

	struct task_struct * task = &init_task;
	do
	{
		if(pid == task->pid)
			break;
		task = next_task(task);
	} while ((task->pid != init_task.pid));
	
	if(task->pid != pid)
		return -1;
	
	printk("######### Loaded files of a process '%s(%d)' in VM ########\n",task->comm, task->pid);

	struct mm_struct *memory_manager = task->mm;
    struct vm_area_struct *virtual_memory_area = memory_manager->mmap;

    char path[1024];

    while(virtual_memory_area != NULL)
    {
        memory_manager = virtual_memory_area->vm_mm;
        if(virtual_memory_area->vm_file != NULL)
        {
            printk("mem[%lx~%lx] code[%lx~%lx] data[%lx~%lx] heap[%lx~%lx] %s\n", virtual_memory_area->vm_start, virtual_memory_area->vm_end, memory_manager->start_code, memory_manager->end_code,
            memory_manager->start_data, memory_manager->end_data, memory_manager->start_brk, memory_manager->brk, d_path(&virtual_memory_area->vm_file->f_path, path, 1024));
        }
        virtual_memory_area = virtual_memory_area->vm_next;
    }
    printk("############################################################\n");
    return pid;
}

void make_rw(void* addr)
{
	unsigned int level;
	pte_t* pte = lookup_address((unsigned long)addr, &level);
	if (pte->pte & ~_PAGE_RW)
		pte->pte |= _PAGE_RW;
}

void make_ro(void* addr)
{
	unsigned int level;
	pte_t* pte = lookup_address((unsigned long)addr, &level);
	pte->pte = pte->pte & ~_PAGE_RW;
}
asmlinkage int __init hooking_init(void)
{
	sys_call_table = (sys_call_ptr_t *)kallsyms_lookup_name("sys_call_table");
	make_rw(sys_call_table);
	real_ftrace = sys_call_table[__NR_ftrace];
	sys_call_table[__NR_ftrace] = (sys_call_ptr_t)file_varea;
	return 0;
}

asmlinkage void __exit hooking_exit(void)
{
	sys_call_table = (sys_call_ptr_t *)kallsyms_lookup_name("sys_call_table");
	sys_call_table[__NR_ftrace] = real_ftrace;
	make_ro(sys_call_table);
}

module_init(hooking_init);
module_exit(hooking_exit);
MODULE_LICENSE("GPL");