#include <stdio.h>
#include <stdint.h> 
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/user.h>
#include <sys/mman.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>

int segment_id;

uint8_t* Operation;
uint8_t* compiled_code;

void sharedmem_init(); // ���� �޸𸮿� ����
void sharedmem_exit();
void drecompile_init(); // memory mapping ���� 
void drecompile_exit(); 
void* drecompile(uint8_t *func); //����ȭ�ϴ� �κ�

int main(void)
{
	int (*func)(int a);
	int i;

	sharedmem_init();
	drecompile_init();

	func = (int (*)(int a))drecompile(Operation);

	struct timespec begin, end;
	clock_gettime(CLOCK_MONOTONIC, &begin);
	int k = func(1);
	clock_gettime(CLOCK_MONOTONIC, &end);


	drecompile_exit();
	sharedmem_exit();
	
    printf("total execution time : %ld.%09ld sec\n", end.tv_sec - begin.tv_sec, end.tv_nsec - begin.tv_nsec);
	return 0;
}

void sharedmem_init()
{
	segment_id = shmget(1234,PAGE_SIZE, IPC_CREAT | S_IRUSR | S_IWUSR);
	Operation = (uint8_t *)shmat(segment_id, NULL, 0);

}

void sharedmem_exit()
{
	shmdt(Operation);
	shmctl(segment_id, IPC_RMID, NULL);
}

void drecompile_init(uint8_t *func)
{
	compiled_code = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, 0, 0);
}

void drecompile_exit()
{
	msync(compiled_code, PAGE_SIZE, MS_SYNC);
	munmap(compiled_code, PAGE_SIZE	);
}

void* drecompile(uint8_t* func)
{
	compiled_code = func;

	#ifdef dynamic
		long compile = 0;
		long index = 0;
		int dl_register = 0;

		while(1)
		{
			if(func[index] == 0xb2)
			{
				dl_register = func[index + 1];
			}
			if(func[index] == 0xc3)
			{
				compiled_code[compile] = 0xc3;
				compile++;
				break;
			}

			else if(func[index] == 0x83 && func[index + 1] == 0xc0)//add
			{
				int add_count = 0;
				while (func[index] == 0x83 && func[index + 1] == 0xc0)
				{
					add_count += func[index + 2];
					index += 3;
				}
				
				compiled_code[compile++] = 0x83;
				compiled_code[compile++] = 0xc0;
				compiled_code[compile++] = add_count;	
			}

			else if(func[index] == 0x83 && func[index + 1] == 0xe8)//sub
			{
				int sub_count = 0;
				while (func[index] == 0x83 && func[index + 1] == 0xe8)
				{
					sub_count += func[index + 2];
					index += 3;
				}
				
				compiled_code[compile++] = 0x83;
				compiled_code[compile++] = 0xe8;
				compiled_code[compile++] = sub_count;	
			}

			else if(func[index] == 0x6b && func[index + 1] == 0xc0)//mul
			{
				int imul_count = 1;
				while (func[index] == 0x6b && func[index + 1] == 0xc0)
				{
					imul_count *= func[index + 2];
					index += 3;
				}
				
				compiled_code[compile++] = 0x6b; 
				compiled_code[compile++] = 0xc0;
				compiled_code[compile++] = imul_count;	
			}

			else if(func[index] == 0xf6 && func[index + 1] == 0xf2)//div
			{
				int div_count = 1;
				while (func[index] == 0xf6 && func[index + 1] == 0xf2)
				{
					div_count *= 2;
					index += 2;
				}
				
				compiled_code[compile++] = 0xb2;
				compiled_code[compile++] = div_count;

				compiled_code[compile++] = 0xf6;
				compiled_code[compile++] = 0xf2;

				compiled_code[compile++] = 0xb2;
				compiled_code[compile++] = 0x02;
			}

			else
			{
				compiled_code[compile] = func[index];
				index++;
				compile++;
			}
		}

	#endif
		mprotect(compiled_code, PAGE_SIZE, PROT_READ | PROT_EXEC);
		return compiled_code;
}